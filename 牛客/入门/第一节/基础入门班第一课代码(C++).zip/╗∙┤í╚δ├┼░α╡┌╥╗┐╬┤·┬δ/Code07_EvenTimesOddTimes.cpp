#include<bits/stdc++.h>
using namespace std;
void printOddTimesNum1(int arr[],int n)
{
    int eor = 0;
    for(int i = 0; i < n ; i ++)
    {
        eor ^= arr[i];
    }
    cout << eor << endl;

}
void printOddTimesNum2(int arr[],int n)
{
    int eor = 0;
    for(int i = 0; i < n; i ++)
    {
        eor ^= arr[i];
    }
    /// eor = a ^ b
    /// eor != 0
    /// eor��Ȼ��һ��λ������1
    int rightOne = eor & (~eor + 1); /// ��ȡ�����ҵ�1
    int onlyOne = 0;
    for(int i = 0;i < n;i ++){
            if((arr[i] & rightOne) == 1){
                onlyOne ^= arr[i];
            }
    }
    cout << onlyOne << " " << (eor ^ onlyOne) << endl;

}
int main()
{
    int a = 5;
    int b = 7;

    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    cout << a << endl;
    cout << b << endl;
    int arr1[] = { 3, 3, 2, 3, 1, 1, 1, 3, 1, 1, 1 };
    int len1 =  sizeof(arr1) / 4;
    printOddTimesNum1(arr1,len1);

    int arr2[] = { 4, 3, 4, 2, 2, 2, 4, 1, 1, 1, 3, 3, 1, 1, 1, 4, 2, 2 };
       int len2 =  sizeof(arr2) / 4;
    printOddTimesNum2(arr2,len2);
    return 0;
}
