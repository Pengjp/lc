#include<bits/stdc++.h>
#include <cstdlib>
using namespace std;
///�Ƚ�
int test(vector<int> arr,int value)
{
    for(int i = 0; i < arr.size(); i ++)
    {
        if(arr[i] >= value)
        {
            return i;
        }

    }
    return -1;

}
///�����������
vector<int>generateRandomArray(int maxSize, int maxValue)
{
    int n = (int) (rand()%(maxSize + 1));
    vector<int>arr(n);
    for (int i = 0; i < n; i++)
    {
        arr[i] = (int) (rand()% (maxValue + 1)) - (int) (rand()% maxValue);
    }
    return arr;
}
///��ӡ����
void printArray(vector<int> arr)
{
    if(arr.size() == 0) return ;
    for(int i = 0; i < arr.size(); i ++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
/// ��arr��������>=value������λ��
int nearestIndex(vector<int> arr, int value)
{
    int L = 0;
    int R = arr.size() - 1;
    int index = -1; /// ��¼�����λ��
    while (L <= R)
    {
        int mid = L + ((R - L) >> 1);
        if (arr[mid] >= value)
        {
            index = mid;
            R = mid - 1;
        }
        else
        {
            L = mid + 1;
        }
    }
    return index;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int testTime = 500000;
    int maxSize = 10;
    int maxValue = 100;
    bool succeed = true;
    for (int i = 0; i < testTime; i++)
    {
        vector<int>arr = generateRandomArray(maxSize, maxValue);
        sort(arr.begin(),arr.end());
        int value = (int) (rand()% (maxValue + 1)) - (int) (rand()% maxValue);
        if (test(arr,value) != nearestIndex(arr, value))
        {
            printArray(arr);
            cout << value <<endl;
            cout << test(arr,value) <<endl;
            cout << nearestIndex(arr, value) << endl;
            succeed = false;
            break;
        }
    }
    if(succeed == true)
    {
        cout <<"Nice!"<<endl;
    }
    else
    {
        cout << "Fucking fucked!" <<endl;
    }
    return 0;
}
