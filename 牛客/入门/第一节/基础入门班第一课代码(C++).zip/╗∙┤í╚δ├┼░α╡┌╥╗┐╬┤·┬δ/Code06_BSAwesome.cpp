#include<bits/stdc++.h>
#include <cstdlib>
using namespace std;
///�����������
vector<int>generateRandomArray(int maxSize, int maxValue)
{
    unsigned seed;
    srand(seed);
    int n = (int) (rand()%(maxSize + 1));
    vector<int>arr(n);
    for (int i = 0; i < n; i++)
    {
        arr[i] = (int) (rand()% (maxValue + 1)) - (int) (rand()% maxValue);
    }
    return arr;
}
///��ӡ����
void printArray(vector<int> arr)
{
    if(arr.size() == 0) return ;
    for(int i = 0; i < arr.size(); i ++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
///�ֲ���Сֵ����
/*
arr ����(���ڲ����) ��������һ���ֲ���С
1) [0] < [1] 0�Ǿֲ���С
2) [N-1] < [N-2] N-1�Ǿֲ���С
3) [i - 1] > [i] < [i + 1] i�Ǿֲ���С
*/
int getLessIndex(vector<int> &arr)
{
    if(arr.size() == 0) return -1;
    if(arr.size() == 1 || arr[0] < arr[1])
    {
        return 0;
    }
    if(arr[arr.size() - 1] < arr[arr.size() - 2])
    {
        return arr.size() - 1;
    }
    int left = 1;
    int right = arr.size() - 2;
    int mid = 0;
    while (left < right)
    {
        mid = (left + right) / 2;
        if (arr[mid] > arr[mid - 1])
        {
            right = mid - 1;
        }
        else if (arr[mid] > arr[mid + 1])
        {
            left = mid + 1;
        }
        else
        {
            return mid;
        }
    }
    return left;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int maxSize = 15;
    int maxValue = 20;
    vector<int>sortedArr = generateRandomArray(maxSize, maxValue);
    printArray(sortedArr);
    int index = getLessIndex(sortedArr);
    cout << "index: " << index << ", value: " << sortedArr[index] << endl;
    return 0;
}
