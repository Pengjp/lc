#include<bits/stdc++.h>
#include <cstdlib>
using namespace std;
///�����������
vector<int>generateRandomArray(int maxSize, int maxValue)
{
    int n = (int) (rand()%(maxSize + 1));
    vector<int>arr(n);
    for (int i = 0; i < n; i++)
    {
        arr[i] = (int) (rand()% (maxValue + 1)) - (int) (rand()% maxValue);
    }
    return arr;
}
///�Ƚ�����ʹ�������Դ������򷽷�������֤
void comparator(vector<int>&arr)
{
    sort(arr.begin(),arr.end());
}
vector<int>copyArray(vector<int>arr)
{
    vector<int> res(arr.size());
    for(int i = 0; i < arr.size(); i ++)
    {
        res[i] = arr[i];
    }
    return res;
}
///�ж����������Ƿ����
bool isEqual(vector<int> arr1,vector<int> arr2)
{
    if (arr1.size() != arr2.size())
    {
        return false;
    }
    for (int i = 0; i < arr1.size(); i++)
    {
        if (arr1[i] != arr2[i])
        {
            return false;
        }
    }
    return true;
}
///��ӡ����
void printArray(vector<int> arr)
{
    if(arr.size() == 0) return ;
    for(int i = 0; i < arr.size(); i ++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
///�������е�����������
void Swap(vector<int> &arr,int i,int j)
{
    int tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}
///ð������
void bubbleSort(vector<int> &arr)
{
    if(arr.size() < 2) return ;
    for(int e = arr.size()-1;e > 0;e --){
        for(int i = 0;i < e;i ++){
            if(arr[i] > arr[i + 1]){
                Swap(arr,i,i + 1);
            }
        }
    }

}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    vector<int>arr1;
    vector<int>arr2;
    unsigned seed;
    seed = time(0);
    srand(seed);
    int testTime = 5000;
    int maxSize = 100;
    int maxValue = 100;
    bool succeed = true;
    for (int i = 0; i < testTime; i++)
    {
        vector<int>arr1 = generateRandomArray(maxSize, maxValue);
        vector<int>arr2 = copyArray(arr1);
        bubbleSort(arr1);
        comparator(arr2);
        if (!isEqual(arr1, arr2))
        {
            succeed = false;
            printArray(arr1);
            printArray(arr2);
            break;
        }
    }
    if(succeed == true)
    {
        cout <<"Nice!"<<endl;
    }
    else
    {
        cout << "Fucking fucked!" <<endl;
    }
    vector<int>arr = generateRandomArray(maxSize, maxValue);
    printArray(arr);
    bubbleSort(arr);
    printArray(arr);
    return 0;


}
