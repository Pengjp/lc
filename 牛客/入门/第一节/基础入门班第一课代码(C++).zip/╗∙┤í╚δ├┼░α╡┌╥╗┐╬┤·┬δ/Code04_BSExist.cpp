#include<bits/stdc++.h>
#include <cstdlib>
using namespace std;
///�����������
vector<int>generateRandomArray(int maxSize, int maxValue)
{
    int n = (int) (rand()%(maxSize + 1));
    vector<int>arr(n);
    for (int i = 0; i < n; i++)
    {
        arr[i] = (int) (rand()% (maxValue + 1)) - (int) (rand()% maxValue);
    }
    return arr;
}
///��ӡ����
void printArray(vector<int> arr)
{
    if(arr.size() == 0) return ;
    for(int i = 0; i < arr.size(); i ++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
///���ֲ���
bool exist(vector<int> &sortedArr, int num)
{
    if(sortedArr.size() == 0) return false;
    int L = 0;
    int R = sortedArr.size() - 1;
    int mid = 0;
    while(L < R)
    {
        mid = L + ((R - L) >> 1);
        if(sortedArr[mid] == num)
        {
            return true;
        }
        else if(sortedArr[mid] > num)
        {
            R = mid - 1;
        }
        else
        {
            L = mid + 1;
        }
    }
    return sortedArr[L] == num;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int maxSize = 100;
    int maxValue = 100;
    vector<int>sortedArr = generateRandomArray(maxSize, maxValue);
    printArray(sortedArr);
    sort(sortedArr.begin(),sortedArr.end());
    printArray(sortedArr);
    int num = (int) (rand()% (maxValue + 1)) - (int) (rand()% maxValue);
    bool succeed = exist(sortedArr,num);
    cout << "The number is :" << num << endl;
     if(succeed == true)
    {
        cout <<"Nice!"<<endl;
    }
    else
    {
        cout << "Fucking fucked!" <<endl;
    }
    return 0;
}
