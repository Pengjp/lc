import random


def Swap(arr, i, j):
    tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp



def printOddTimesNum1(arr,n):
    eor = 0
    for i in range(n):
        eor ^= arr[i]
    print(eor)


def printOddTimesNum2(arr,n):
    eor = 0
    for i in range(n):
        eor ^= arr[i]
    rightOne = eor & (~eor + 1)
    onlyOne = 0
    for i in range(n):
        if (arr[i] & rightOne) == 1:
            onlyOne ^= arr[i]
    a = onlyOne
    b = (eor ^ onlyOne)
    if a > b :
        a =(eor ^ onlyOne)
        b = onlyOne
    print(a,end=" ")
    print(b)

if __name__ == "__main__":
    n = int(input())
    arr = list(map(int, input().strip().split()))
    printOddTimesNum2(arr,n)


