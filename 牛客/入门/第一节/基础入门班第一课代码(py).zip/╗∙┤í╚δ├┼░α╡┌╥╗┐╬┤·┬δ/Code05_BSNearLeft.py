import random



def Swap(arr, i, j):
    tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp


def nearestIndex(arr,value):
    L = 0
    R = len(arr) - 1
    index = -1
    while(L <= R):
        mid = int((L + ((R - L) >> 1)))
        if arr[mid] >= value:
            index = mid
            R = mid - 1
        else:
            L = mid + 1
    return  index


def comparator(arr,value):
    for i in range(len(arr)):
        if arr[i] >= value:
            return i
    return -1


def copyArray(arr):
    if arr == None:
        return None
    res = [0]*(len(arr))
    for i in range(len(arr)):
        res[i] = arr[i]
    return res

def isEqual(arr1,arr2):
    if ((arr1 == None and arr2 != None)) or ((arr1 != None and arr2 == None)):
        return False
    if arr1 == None and arr2 == None:
        return True
    if len(arr1) != len(arr2):
        return False
    for i in range(len(arr1)):
        if arr1[i] != arr2[i]:
            return False
    return True
def printArray(arr):
    if arr == None:
        return
    for i in range(len(arr)):
        print(arr[i],end=" ")
    print("")
def generateRandomArray(maxSize,maxValue):
    arr = [0]* int((maxSize + 1) * random.random())
    for i in range(len(arr)):
        arr[i] = int(((maxValue + 1) * random.random()) - (int(maxValue * random.random())))

    return arr


if __name__ == "__main__":
    testTime = 5000
    maxSize = 100
    maxValue = 100
    succeed = True
    for i in range(testTime):
        arr1 = generateRandomArray(maxSize, maxValue)
        arr1 = sorted(arr1)
        value = int(int(random.random() * (maxValue + 1)) - int(random.random() *maxValue))
        if comparator(arr1,value) != nearestIndex(arr1,value):
            printArray(arr1)
            print(value)
            print(comparator(arr1,value))
            print(nearestIndex(arr1,value))
            succeed = False
            break
    if succeed == True:
        print("Nice!")
    else:
        print("Fucking fucked")

