import random


def Swap(arr, i, j):
    tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp



def bubbleSort(arr):
   for e in range(len(arr)-1,0,-1):
       for i in range(e):
           if arr[i] > arr[i + 1]:
               Swap(arr,i,i + 1)


def comparator(arr):
    sorted(arr)

def copyArray(arr):
    if arr == None:
        return None
    res = [0]*(len(arr))
    for i in range(len(arr)):
        res[i] = arr[i]
    return res

def isEqual(arr1,arr2):
    if ((arr1 == None and arr2 != None)) or ((arr1 != None and arr2 == None)):
        return False
    if arr1 == None and arr2 == None:
        return True
    if len(arr1) != len(arr2):
        return False
    for i in range(len(arr1)):
        if arr1[i] != arr2[i]:
            return False
    return True
def printArray(arr):
    if arr == None:
        return
    for i in range(len(arr)):
        print(arr[i],end=" ")
    print("")
def generateRandomArray(maxSize,maxValue):
    arr = [0]* int((maxSize + 1) * random.random())
    for i in range(len(arr)):
        arr[i] = int(((maxValue + 1) * random.random()) - (int(maxValue * random.random())))

    return arr


if __name__ == "__main__":
    testTime = 5000
    maxSize = 100
    maxValue = 100
    succeed = True
    for i in range(testTime):
        arr1 = generateRandomArray(maxSize, maxValue)
        arr2 = copyArray(arr1)
        bubbleSort(arr1)
        comparator(arr2)
        if isEqual(arr1, arr2) == False:
            succeed = False
            printArray(arr1)
            printArray(arr2)
            break
    if succeed == False:
        print("Nice!")
    else:
        print("Fucking fucked")
    arr = generateRandomArray(maxSize, maxValue)
    printArray(arr)
    bubbleSort(arr)
    printArray(arr)


