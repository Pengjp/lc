import random


def Swap(arr, i, j):
    tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp



def process(arr,L,R):
    if L == R:
        return arr[L]
    mid = L + ((R - L) >> 1)
    leftMax = process(arr,L,mid)
    rightMax = process(arr,mid + 1,R)
    return max(leftMax,rightMax)
def getMax(arr):
    return process(arr,0,len(arr) - 1)

if __name__ == "__main__":
    n = int(input())
    arr = list(map(int, input().strip().split()))
    res = getMax(arr)
    print(res)

