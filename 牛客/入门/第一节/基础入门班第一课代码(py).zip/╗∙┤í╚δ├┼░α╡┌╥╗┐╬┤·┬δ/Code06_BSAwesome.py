import random



def Swap(arr, i, j):
    tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp

'''�ֲ���Сֵ����
arr ����(���ڲ����) ��������һ���ֲ���С
1) [0] < [1] 0�Ǿֲ���С
2) [N-1] < [N-2] N-1�Ǿֲ���С
3) [i - 1] > [i] < [i + 1] i�Ǿֲ���С
'''
def getLessIndex(arr):
    if len(arr) == 0: return -1
    if len(arr) == 1 or arr[0] < arr[1]:
        return 0
    if arr[len(arr) - 1] < arr[len(arr) - 2]:
        return len(arr) - 1
    left = 1
    right = len(arr) - 2
    mid = 0
    while left < right:
        mid = int((left + right) / 2)
        if arr[mid] > arr[mid - 1]:
            right = mid - 1
        elif arr[mid] > arr[mid + 1]:
            left = mid + 1
        else:
            return  mid

    return  left



def printArray(arr):
    if arr == None:
        return
    for i in range(len(arr)):
        print(arr[i],end=" ")
    print("")
def generateRandomArray(maxSize,maxValue):
    arr = [0]* int((maxSize + 1) * random.random())
    for i in range(len(arr)):
        arr[i] = int(((maxValue + 1) * random.random()) - (int(maxValue * random.random())))

    return arr


if __name__ == "__main__":
    maxSize = 10
    maxValue = 10
    arr = generateRandomArray(maxSize, maxValue)
    printArray(arr)
    index = getLessIndex(arr)
    print(index)
    print(arr[index])

