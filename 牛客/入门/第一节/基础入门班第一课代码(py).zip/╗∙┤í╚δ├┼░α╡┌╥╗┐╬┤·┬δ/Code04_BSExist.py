import random


def Swap(arr, i, j):
    tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp



def exist(sortedArr,num):
    if len(sortedArr) == 0:
        return False
    L = 0
    R = len(sortedArr) - 1
    while L < R:
        mid = int((L + R) / 2)
        if sortedArr[mid] == num:
            return True
        elif sortedArr[mid] > num:
            R = mid - 1
        else:
            L = mid + 1

    if sortedArr[L] == num:
        return True
    else:
        return False






def printArray(arr):
    if arr == None:
        return
    for i in range(len(arr)):
        print(arr[i],end=" ")
    print("")
def generateRandomArray(maxSize,maxValue):
    arr = [0]* int((maxSize + 1) * random.random())
    for i in range(len(arr)):
        arr[i] = int(((maxValue + 1) * random.random()) - (int(maxValue * random.random())))

    return arr


if __name__ == "__main__":
    testTime = 5000
    maxSize = 10
    maxValue = 10
    sortedArr = generateRandomArray(maxSize, maxValue)
    print(sortedArr)
    sorted(sortedArr)
    print(sortedArr)
    num = int(random.random()*(maxValue))
    print("The number is :",end=" ")
    print(num)
    succeed = exist(sortedArr,num)
    if succeed == True:
        print("Nice!")
    else:
        print("Fucking fucked")


